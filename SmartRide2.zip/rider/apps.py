from django.apps import AppConfig


class RiderConfig(AppConfig):
    name = 'rider'
